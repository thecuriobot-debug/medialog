<?php
require_once 'config.php';

// Get all active sites
$pdo = getDB();
$stmt = $pdo->query("SELECT * FROM sites WHERE status = 'active' ORDER BY name");
$sites = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Get latest 3 posts for each site
$sitesPosts = [];
foreach ($sites as $site) {
    $stmt = $pdo->prepare("
        SELECT title, url, publish_date, description, image_url
        FROM posts 
        WHERE site_id = ?
        ORDER BY publish_date DESC
        LIMIT 3
    ");
    $stmt->execute([$site['id']]);
    $sitesPosts[$site['id']] = [
        'site' => $site,
        'posts' => $stmt->fetchAll(PDO::FETCH_ASSOC)
    ];
}

// Get last scan timestamp
$stmt = $pdo->query("SELECT MAX(last_checked) as last_scan FROM sites");
$last_scan = $stmt->fetch(PDO::FETCH_ASSOC)['last_scan'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Hunt HQ - Content Monitor</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Georgia', 'Times New Roman', serif;
            background: #f5f5f5;
            padding: 0;
            color: #1a1a1a;
        }
        
        /* Top Navigation Menu */
        .top-nav {
            background: #1a1a1a;
            border-bottom: 3px solid #d4af37;
            padding: 0;
            position: sticky;
            top: 0;
            z-index: 1000;
            box-shadow: 0 2px 10px rgba(0,0,0,0.3);
        }
        
        .nav-container {
            max-width: 1400px;
            margin: 0 auto;
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 0 20px;
        }
        
        .nav-brand {
            font-family: 'Georgia', serif;
            font-size: 24px;
            font-weight: bold;
            color: #d4af37;
            padding: 15px 0;
            text-decoration: none;
            letter-spacing: 1px;
        }
        
        .nav-links {
            display: flex;
            list-style: none;
            gap: 0;
        }
        
        .nav-links a {
            display: block;
            padding: 20px 20px;
            color: #fff;
            text-decoration: none;
            font-size: 14px;
            font-weight: 500;
            transition: all 0.3s ease;
            border-bottom: 3px solid transparent;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }
        
        .nav-links a:hover {
            background: #2a2a2a;
            border-bottom-color: #d4af37;
        }
        
        .nav-links a.active {
            background: #2a2a2a;
            border-bottom-color: #d4af37;
        }
        
        .main-content {
            padding: 20px;
        }
        
        .container {
            max-width: 1400px;
            margin: 0 auto;
            background: white;
            box-shadow: 0 0 30px rgba(0, 0, 0, 0.1);
        }
        
        /* Newspaper Header */
        .masthead {
            border-bottom: 4px double #1a1a1a;
            padding: 30px 40px 20px;
            background: white;
        }
        
        .masthead-top {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 15px;
            font-size: 0.85em;
            color: #666;
        }
        
        h1 {
            font-family: 'Georgia', serif;
            font-size: 4em;
            text-align: center;
            font-weight: bold;
            letter-spacing: 2px;
            margin-bottom: 5px;
            text-transform: uppercase;
        }
        
        .tagline {
            text-align: center;
            font-style: italic;
            font-size: 1.1em;
            color: #666;
            margin-bottom: 15px;
            border-top: 1px solid #ddd;
            border-bottom: 1px solid #ddd;
            padding: 8px 0;
        }
        
        .control-bar {
            display: flex;
            justify-content: center;
            gap: 20px;
            padding: 15px 0;
            border-top: 1px solid #ddd;
        }
        
        .scan-button {
            background: #1a1a1a;
            color: white;
            border: 2px solid #1a1a1a;
            padding: 10px 30px;
            font-size: 0.9em;
            font-weight: bold;
            cursor: pointer;
            text-transform: uppercase;
            letter-spacing: 1px;
            transition: all 0.2s;
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
        }
        
        .scan-button:hover {
            background: white;
            color: #1a1a1a;
        }
        
        .scan-button:disabled {
            background: #ccc;
            border-color: #ccc;
            cursor: not-allowed;
        }
        
        /* Main Content Grid */
        .content-grid {
            display: grid;
            grid-template-columns: repeat(6, 1fr);
            gap: 0;
            border-top: 2px solid #1a1a1a;
        }
        
        .column {
            border-right: 1px solid #ddd;
            padding: 30px;
        }
        
        .column:last-child {
            border-right: none;
        }
        
        .column-header {
            font-size: 1.8em;
            font-weight: bold;
            margin-bottom: 20px;
            padding-bottom: 10px;
            border-bottom: 3px solid #1a1a1a;
            text-transform: uppercase;
            letter-spacing: 1px;
        }
        
        /* Article Styles */
        .article {
            margin-bottom: 30px;
            padding-bottom: 25px;
            border-bottom: 1px solid #e0e0e0;
        }
        
        .article:last-child {
            border-bottom: none;
        }
        
        .article-image {
            width: 100%;
            height: 220px;
            object-fit: contain;
            background: #f9f9f9;
            margin-bottom: 12px;
            border: 1px solid #ddd;
        }
        
        .article-title {
            font-size: 1.3em;
            font-weight: bold;
            line-height: 1.3;
            margin-bottom: 8px;
        }
        
        .article-title a {
            color: #1a1a1a;
            text-decoration: none;
            transition: color 0.2s;
        }
        
        .article-title a:hover {
            color: #666;
        }
        
        .article-meta {
            font-size: 0.75em;
            color: #999;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            margin-bottom: 10px;
            font-family: -apple-system, sans-serif;
        }
        
        .article-description {
            font-size: 0.95em;
            line-height: 1.6;
            color: #333;
        }
        
        .no-posts {
            color: #999;
            font-style: italic;
            text-align: center;
            padding: 40px 20px;
        }
        
        /* Loading/Results */
        .loading {
            display: none;
            text-align: center;
            padding: 20px;
            background: #fffbea;
            border: 2px solid #f0ad4e;
            margin: 20px 40px;
        }
        
        .loading.active {
            display: block;
        }
        
        .scan-results {
            display: none;
            background: #d4edda;
            border: 2px solid #28a745;
            padding: 20px;
            margin: 20px 40px;
        }
        
        .scan-results.active {
            display: block;
        }
        
        /* Responsive */
        @media (max-width: 1024px) {
            .content-grid {
                grid-template-columns: 1fr;
            }
            
            .column {
                border-right: none;
                border-bottom: 2px solid #1a1a1a;
            }
            
            .column:last-child {
                border-bottom: none;
            }
            
            h1 {
                font-size: 2.5em;
            }
        }
    </style>
</head>
<body>
    <!-- Top Navigation Menu -->
    <nav class="top-nav">
        <div class="nav-container">
            <a href="index.php" class="nav-brand">HUNT HQ</a>
            <ul class="nav-links">
                <li><a href="index.php" class="active">Dashboard</a></li>
                <li><a href="books.php">Books</a></li>
                <li><a href="movies.php">Movies</a></li>
                <li><a href="authors.php">Authors</a></li>
                <li><a href="stats.php">Statistics</a></li>
                <li><a href="insights.php">Insights</a></li>
            </ul>
        </div>
    </nav>
    
    <div class="main-content">
    <div class="container">
        <div class="masthead">
            <div class="masthead-top">
                <div><?= date('l, F j, Y') ?></div>
                <div id="current-time"><?= date('g:i A') ?></div>
            </div>
            
            <h1>Hunt HQ</h1>
            
            <div class="tagline">
                Your Personal Content Intelligence Report
            </div>
            
            <div class="control-bar">
                <button id="scan-btn" class="scan-button">⟳ Update Now</button>
                <div style="font-size: 0.85em; color: #666; padding: 10px 0;">
                    Last Updated: <strong id="last-scan"><?= $last_scan ? date('g:i A', strtotime($last_scan)) : 'Never' ?></strong>
                </div>
            </div>
        </div>
        
        <div class="loading" id="loading">
            <strong>⟳ Scanning all sources...</strong>
        </div>
        
        <div class="scan-results" id="scan-results"></div>
        
        <div class="content-grid">
            <?php foreach ($sitesPosts as $data): ?>
            <div class="column">
                <div class="column-header"><?= htmlspecialchars($data['site']['name']) ?></div>
                
                <?php if (empty($data['posts'])): ?>
                    <div class="no-posts">No recent articles</div>
                <?php else: ?>
                    <?php foreach ($data['posts'] as $post): ?>
                    <?php
                        // Create local URLs for books and movies
                        $localUrl = $post['url'];
                        $siteName = $data['site']['name'];
                        
                        if ($siteName === 'Goodreads') {
                            // Extract book ID from Goodreads URL
                            if (preg_match('/show\/(\d+)/', $post['url'], $matches)) {
                                $localUrl = "review.php?id={$matches[1]}";
                            }
                        } elseif ($siteName === 'Letterboxd') {
                            // Extract movie ID from Letterboxd URL
                            if (preg_match('#/film/([^/]+)#', $post['url'], $matches)) {
                                $localUrl = "movie.php?id={$matches[1]}";
                            }
                        }
                    ?>
                    <article class="article">
                        <?php if (!empty($post['image_url'])): ?>
                        <img src="<?= htmlspecialchars($post['image_url']) ?>" alt="" class="article-image" onerror="this.style.display='none'">
                        <?php endif; ?>
                        
                        <div class="article-title">
                            <a href="<?= htmlspecialchars($localUrl) ?>">
                                <?= htmlspecialchars($post['title']) ?>
                            </a>
                        </div>
                        
                        <div class="article-meta">
                            <?= $post['publish_date'] ? date('M j, Y · g:i A', strtotime($post['publish_date'])) : 'Date unknown' ?>
                        </div>
                        
                        <?php if (!empty($post['description'])): ?>
                        <div class="article-description">
                            <?= htmlspecialchars(substr($post['description'], 0, 200)) ?><?= strlen($post['description']) > 200 ? '...' : '' ?>
                        </div>
                        <?php endif; ?>
                    </article>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
    
    <script>
        // Update current time
        function updateTime() {
            const now = new Date();
            document.getElementById('current-time').textContent = 
                now.toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit', hour12: true });
        }
        setInterval(updateTime, 1000);
        
        // Scan button
        document.getElementById('scan-btn').addEventListener('click', async function() {
            const button = this;
            const loading = document.getElementById('loading');
            const resultsDiv = document.getElementById('scan-results');
            
            button.disabled = true;
            loading.classList.add('active');
            resultsDiv.classList.remove('active');
            
            try {
                const formData = new FormData();
                formData.append('action', 'scan');
                
                const response = await fetch('scanner.php', {
                    method: 'POST',
                    body: formData
                });
                
                const data = await response.json();
                
                if (data.success) {
                    const scanTime = new Date(data.timestamp);
                    document.getElementById('last-scan').textContent = 
                        scanTime.toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit', hour12: true });
                    
                    let resultsHTML = '<strong>Scan Complete:</strong> ';
                    let totalNew = 0;
                    
                    for (const [siteId, result] of Object.entries(data.results)) {
                        totalNew += result.new_posts;
                        resultsHTML += `${result.site}: ${result.new_posts} new · `;
                    }
                    
                    resultsDiv.innerHTML = resultsHTML;
                    resultsDiv.classList.add('active');
                    
                    if (totalNew > 0) {
                        setTimeout(() => window.location.reload(), 2000);
                    }
                }
            } catch (error) {
                alert('Scan failed: ' + error.message);
            } finally {
                loading.classList.remove('active');
                button.disabled = false;
            }
        });
    </script>
    </div><!-- .main-content -->
</body>
</html>
