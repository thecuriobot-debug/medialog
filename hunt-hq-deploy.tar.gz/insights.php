<?php
require_once 'config.php';

$pdo = getDB();

// Get all books with full data
$stmt = $pdo->query("
    SELECT title, publish_date, description, full_content
    FROM posts 
    WHERE site_id = 7
    ORDER BY publish_date DESC
");

$books = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Parse all the data
$insights = [];

// 1. Longest vs Shortest Books
$booksByPages = [];
foreach ($books as $book) {
    if (preg_match('/(\d+)\s+pages/', $book['description'], $matches)) {
        $pages = (int)$matches[1];
        $booksByPages[] = [
            'title' => $book['title'],
            'pages' => $pages
        ];
    }
}
usort($booksByPages, fn($a, $b) => $b['pages'] - $a['pages']);
$insights['longest'] = array_slice($booksByPages, 0, 5);
$insights['shortest'] = array_slice(array_reverse($booksByPages), 0, 5);

// 2. Reading Streaks
$dates = array_map(fn($b) => date('Y-m-d', strtotime($b['publish_date'])), $books);
sort($dates);
$currentStreak = 1;
$longestStreak = 1;
$tempStreak = 1;

for ($i = 1; $i < count($dates); $i++) {
    $diff = (strtotime($dates[$i]) - strtotime($dates[$i-1])) / 86400;
    if ($diff <= 7) { // Within a week = streak continues
        $tempStreak++;
        $longestStreak = max($longestStreak, $tempStreak);
    } else {
        $tempStreak = 1;
    }
}

// Check current streak
$lastReadDate = strtotime($dates[count($dates) - 1]);
$daysSinceLastRead = (time() - $lastReadDate) / 86400;
if ($daysSinceLastRead <= 7) {
    $currentStreak = $tempStreak;
}

$insights['currentStreak'] = $currentStreak;
$insights['longestStreak'] = $longestStreak;

// 3. Most Productive Month Ever
$monthCounts = [];
foreach ($books as $book) {
    $month = date('Y-m', strtotime($book['publish_date']));
    if (!isset($monthCounts[$month])) {
        $monthCounts[$month] = 0;
    }
    $monthCounts[$month]++;
}
arsort($monthCounts);
$bestMonth = array_key_first($monthCounts);
$bestMonthCount = $monthCounts[$bestMonth];

// 4. Publishers
$publishers = [];
foreach ($books as $book) {
    if (preg_match('/Publisher:\s*([^·]+)/', $book['description'], $matches)) {
        $pub = trim($matches[1]);
        if (!isset($publishers[$pub])) {
            $publishers[$pub] = 0;
        }
        $publishers[$pub]++;
    }
}
arsort($publishers);
$topPublishers = array_slice($publishers, 0, 10, true);

// 5. Average book length by rating
$pagesByRating = [];
$countsByRating = [];
foreach ($books as $book) {
    $stars = substr_count($book['title'], '★');
    if ($stars > 0 && preg_match('/(\d+)\s+pages/', $book['description'], $matches)) {
        $pages = (int)$matches[1];
        if (!isset($pagesByRating[$stars])) {
            $pagesByRating[$stars] = 0;
            $countsByRating[$stars] = 0;
        }
        $pagesByRating[$stars] += $pages;
        $countsByRating[$stars]++;
    }
}

$avgPagesByRating = [];
foreach ($pagesByRating as $stars => $totalPages) {
    $avgPagesByRating[$stars] = round($totalPages / $countsByRating[$stars]);
}

// 6. Format distribution (Hardcover, Paperback, Kindle, etc.)
$formats = [];
foreach ($books as $book) {
    if (preg_match('/(Hardcover|Paperback|Kindle|Audio|Mass Market)/i', $book['description'], $matches)) {
        $format = $matches[1];
        if (!isset($formats[$format])) {
            $formats[$format] = 0;
        }
        $formats[$format]++;
    }
}
arsort($formats);

// 7. Review word count
$totalReviewWords = 0;
$reviewCount = 0;
foreach ($books as $book) {
    if (strlen($book['full_content']) > 100) {
        $wordCount = str_word_count(strip_tags($book['full_content']));
        $totalReviewWords += $wordCount;
        $reviewCount++;
    }
}
$avgReviewWords = $reviewCount > 0 ? round($totalReviewWords / $reviewCount) : 0;

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reading Insights - Hunt HQ</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Georgia', 'Times New Roman', serif;
            background: #f5f5f5;
            padding: 0;
            color: #1a1a1a;
        }
        
        .top-nav {
            background: #1a1a1a;
            border-bottom: 3px solid #d4af37;
            padding: 0;
            position: sticky;
            top: 0;
            z-index: 1000;
            box-shadow: 0 2px 10px rgba(0,0,0,0.3);
        }
        
        .nav-container {
            max-width: 1400px;
            margin: 0 auto;
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 0 20px;
        }
        
        .nav-brand {
            font-family: 'Georgia', serif;
            font-size: 24px;
            font-weight: bold;
            color: #d4af37;
            padding: 15px 0;
            text-decoration: none;
            letter-spacing: 1px;
        }
        
        .nav-links {
            display: flex;
            list-style: none;
            gap: 0;
        }
        
        .nav-links a {
            display: block;
            padding: 20px 20px;
            color: #fff;
            text-decoration: none;
            font-size: 14px;
            font-weight: 500;
            transition: all 0.3s ease;
            border-bottom: 3px solid transparent;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }
        
        .nav-links a:hover {
            background: #2a2a2a;
            border-bottom-color: #d4af37;
        }
        
        .nav-links a.active {
            background: #2a2a2a;
            border-bottom-color: #d4af37;
        }
        
        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 40px 20px;
        }
        
        h1 {
            font-size: 2.5em;
            margin-bottom: 10px;
            color: #1a1a1a;
        }
        
        .subtitle {
            color: #666;
            margin-bottom: 40px;
            font-size: 1.1em;
        }
        
        .insights-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(350px, 1fr));
            gap: 20px;
            margin-bottom: 20px;
        }
        
        .insight-card {
            background: white;
            padding: 25px;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        
        .insight-title {
            font-size: 1.3em;
            margin-bottom: 15px;
            color: #1a1a1a;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        .insight-icon {
            font-size: 1.5em;
        }
        
        .insight-value {
            font-size: 2.5em;
            font-weight: bold;
            color: #d4af37;
            margin: 15px 0;
        }
        
        .insight-description {
            color: #666;
            line-height: 1.6;
        }
        
        .book-list {
            list-style: none;
            margin-top: 15px;
        }
        
        .book-list li {
            padding: 8px 0;
            border-bottom: 1px solid #f0f0f0;
            color: #333;
        }
        
        .book-list li:last-child {
            border-bottom: none;
        }
        
        .pages-badge {
            background: #d4af37;
            color: white;
            padding: 2px 8px;
            border-radius: 3px;
            font-size: 0.85em;
            font-weight: bold;
            margin-left: 10px;
        }
        
        .simple-bar {
            display: flex;
            align-items: center;
            gap: 10px;
            margin: 8px 0;
        }
        
        .simple-bar-label {
            min-width: 120px;
            font-size: 0.9em;
        }
        
        .simple-bar-track {
            flex: 1;
            background: #f0f0f0;
            height: 20px;
            border-radius: 3px;
            overflow: hidden;
        }
        
        .simple-bar-fill {
            background: #d4af37;
            height: 100%;
            display: flex;
            align-items: center;
            justify-content: flex-end;
            padding: 0 5px;
            font-size: 0.8em;
            color: white;
            font-weight: bold;
        }
    </style>
</head>
<body>
    <nav class="top-nav">
        <div class="nav-container">
            <a href="index.php" class="nav-brand">HUNT HQ</a>
            <ul class="nav-links">
                <li><a href="index.php">Dashboard</a></li>
                <li><a href="books.php">Books</a></li>
                <li><a href="movies.php">Movies</a></li>
                <li><a href="authors.php">Authors</a></li>
                <li><a href="stats.php">Statistics</a></li>
                <li><a href="insights.php" class="active">Insights</a></li>
            </ul>
        </div>
    </nav>
    
    <div class="container">
        <h1>💡 Reading Insights</h1>
        <div class="subtitle">Discover patterns in your reading journey</div>
        
        <div class="insights-grid">
            <!-- Current Reading Streak -->
            <div class="insight-card">
                <div class="insight-title">
                    <span class="insight-icon">🔥</span>
                    Current Reading Streak
                </div>
                <div class="insight-value"><?= $currentStreak ?> books</div>
                <div class="insight-description">
                    Your longest streak was <?= $longestStreak ?> books. Keep going!
                </div>
            </div>
            
            <!-- Best Month -->
            <div class="insight-card">
                <div class="insight-title">
                    <span class="insight-icon">🏆</span>
                    Most Productive Month
                </div>
                <div class="insight-value"><?= $bestMonthCount ?> books</div>
                <div class="insight-description">
                    <?= date('F Y', strtotime($bestMonth . '-01')) ?> was your best reading month ever!
                </div>
            </div>
            
            <!-- Average Review Length -->
            <div class="insight-card">
                <div class="insight-title">
                    <span class="insight-icon">✍️</span>
                    Review Writing
                </div>
                <div class="insight-value"><?= number_format($avgReviewWords) ?> words</div>
                <div class="insight-description">
                    Average review length. You've written <?= number_format($totalReviewWords) ?> words total!
                </div>
            </div>
        </div>
        
        <!-- Longest Books -->
        <div class="insight-card" style="margin-bottom: 20px;">
            <div class="insight-title">
                <span class="insight-icon">📏</span>
                Longest Books You've Read
            </div>
            <ul class="book-list">
                <?php foreach ($insights['longest'] as $book): ?>
                    <li>
                        <?= htmlspecialchars($book['title']) ?>
                        <span class="pages-badge"><?= number_format($book['pages']) ?> pages</span>
                    </li>
                <?php endforeach; ?>
            </ul>
        </div>
        
        <!-- Top Publishers -->
        <div class="insight-card" style="margin-bottom: 20px;">
            <div class="insight-title">
                <span class="insight-icon">🏢</span>
                Top Publishers
            </div>
            <?php 
            $maxPub = max($topPublishers);
            foreach (array_slice($topPublishers, 0, 8) as $publisher => $count): 
                $width = $maxPub > 0 ? ($count / $maxPub) * 100 : 0;
            ?>
                <div class="simple-bar">
                    <div class="simple-bar-label"><?= htmlspecialchars(substr($publisher, 0, 25)) ?></div>
                    <div class="simple-bar-track">
                        <div class="simple-bar-fill" style="width: <?= $width ?>%">
                            <?= $count ?>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
        
        <!-- Format Preferences -->
        <?php if (!empty($formats)): ?>
        <div class="insight-card" style="margin-bottom: 20px;">
            <div class="insight-title">
                <span class="insight-icon">📱</span>
                Reading Format Preferences
            </div>
            <?php 
            $maxFormat = max($formats);
            foreach ($formats as $format => $count): 
                $width = $maxFormat > 0 ? ($count / $maxFormat) * 100 : 0;
            ?>
                <div class="simple-bar">
                    <div class="simple-bar-label"><?= htmlspecialchars($format) ?></div>
                    <div class="simple-bar-track">
                        <div class="simple-bar-fill" style="width: <?= $width ?>%">
                            <?= $count ?>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
        <?php endif; ?>
        
        <!-- Average Pages by Rating -->
        <div class="insight-card">
            <div class="insight-title">
                <span class="insight-icon">⭐</span>
                Average Book Length by Rating
            </div>
            <div class="insight-description" style="margin-bottom: 15px;">
                Do you prefer longer or shorter books for different ratings?
            </div>
            <?php foreach ([5, 4, 3, 2, 1] as $stars): ?>
                <?php if (isset($avgPagesByRating[$stars])): ?>
                    <div class="simple-bar">
                        <div class="simple-bar-label"><?= str_repeat('★', $stars) ?></div>
                        <div class="simple-bar-track">
                            <div class="simple-bar-fill" style="width: <?= ($avgPagesByRating[$stars] / 1000) * 100 ?>%">
                                <?= $avgPagesByRating[$stars] ?> pages
                            </div>
                        </div>
                    </div>
                <?php endif; ?>
            <?php endforeach; ?>
        </div>
    </div>
</body>
</html>
